package com.ws.spring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ws.spring.model.Module;


@Repository
public interface ModuleRepository  extends JpaRepository<Module, String>{
	
Module findModuletByModuleId(long moduleId);
	
Module findModuleByModuleName(String moduleName);
	
Module findModuleByAccessLevel(long accessLevel);

@Query("select m from Module m where m.course is null")
List<Module> queryUnassociatedModules();

}
