package com.ws.spring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ws.spring.model.Topic;


@Repository
public interface TopicRepository  extends JpaRepository<Topic, String> {
	
	Topic findTopicByTopicId(long topicId);
	
	Topic findTopicByTopicName(String topicName);
	
	Topic findTopicByAccessLevel(long accessLevel);
	
	@Query("select t from Topic t where t.module is null")
	List<Topic> queryUnassociatedTopics();

	
}
