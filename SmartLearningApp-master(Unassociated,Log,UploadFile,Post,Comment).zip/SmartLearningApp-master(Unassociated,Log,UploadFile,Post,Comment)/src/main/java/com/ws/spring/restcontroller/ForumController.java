package com.ws.spring.restcontroller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ws.spring.model.Forum;
import com.ws.spring.service.ForumServiceImpl;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/Forum")
@Api(value = "Forum Management System", tags = "Operations pertaining to Forum in Forum Management System")
public class ForumController
{
	@Autowired
	ForumServiceImpl forumService;
	
	@PostMapping("/v1/createForum")
	ResponseEntity<String> createForum(@RequestBody Forum forum) {
		log.debug("createForum forumName : {}" + forum.getForumName());
		Forum forumCreated = forumService.createForum(forum);
		log.debug("created Forum forumId : {}" + forumCreated.getForumId());
		return ResponseEntity.created(URI.create("/forum/v1/queryForumById/" + forumCreated.getForumId())).body("");
	}

	@PostMapping("/v1/updateForum")
	ResponseEntity<String> updateForum(@RequestBody Forum forum) {
		Forum forumCreated = forumService.updateForum(forum);
		return ResponseEntity.created(URI.create("/forum/v1/queryForumById/" + forumCreated.getForumId())).body("");
	}

}
