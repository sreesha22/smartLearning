package com.ws.spring.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;

@Entity
@Table(name = "t_ws_comment")
@DynamicUpdate
@Data
public class Comment
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long commentId;
	
	@OneToOne(targetEntity=Post.class,cascade=CascadeType.ALL)
	@JoinColumn(name = "postId")
	private Post post;

}
