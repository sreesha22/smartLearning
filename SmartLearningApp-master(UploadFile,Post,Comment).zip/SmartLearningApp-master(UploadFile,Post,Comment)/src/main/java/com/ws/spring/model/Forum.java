package com.ws.spring.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;

@Entity
@Table(name = "t_ws_forum")
@DynamicUpdate
@Data
public class Forum 
{

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long forumId;
	
	@Column(unique = true)
	private String forumName;
	
	private String description;
	
	private String listOfPost;
	
	private int status;
	
	private String accessLevel;
	
	@OneToOne(targetEntity=Group.class,cascade=CascadeType.ALL,fetch = FetchType.LAZY)  
	private Group group;  
	
	public Forum()
	{
		
		
	}
	public Forum(long forumId, String forumName, String description,String accessLevel, String listOfPost, int status, Group group)
	{
		super();
		this.forumId = forumId;
		this.forumName = forumName;
		this.description = description;
		this.status = status;
		this.accessLevel = accessLevel;
		
		this.group = group;
	
	}
}
