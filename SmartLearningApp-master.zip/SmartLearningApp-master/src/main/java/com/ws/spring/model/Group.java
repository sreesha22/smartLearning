package com.ws.spring.model;



import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;

@Entity
@Table(name = "t_ws_group")
@DynamicUpdate
@Data
public class Group {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long groupId;
	
	@Column(unique = true)
	private String groupName;
	
	private String description;
	
	 private int status;
	 
	private long accessLevel;
	
	private String draft;
	
	private String aprove;

	@ManyToOne(cascade=CascadeType.PERSIST, fetch = FetchType.LAZY)
	private College collegeId;
}
