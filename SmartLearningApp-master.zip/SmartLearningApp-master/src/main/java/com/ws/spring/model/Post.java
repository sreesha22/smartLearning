package com.ws.spring.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;

@Entity
@Table(name = "t_ws_post")
@DynamicUpdate
@Data
public class Post 
{

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long postId;
	
	private String tags;

	
	
	//@Column(unique = true)
	@ManyToOne(cascade= {CascadeType.ALL})
	@JoinColumn(name = "parent_post_id")
	private Post parentPost;
	
	@OneToMany(mappedBy = "parentPost")
	private Set<Post> subPost = new HashSet<Post>();
	
	public Post() {
	}

	public Post(long postId, String tags) {
		this.postId = postId;
		this.tags = tags;
	}

	
}
