package com.ws.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ws.spring.model.Comment;

public interface CommentRepository extends JpaRepository<Comment, Long>
{

	Comment findCommentByCommentId(long commentId);
}
