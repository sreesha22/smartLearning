package com.ws.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ws.spring.model.Forum;

public interface ForumRepository extends JpaRepository<Forum, Long>
{

	Forum findForumByForumId(long forumId);

	Forum findForumByForumName(String forumName);

	Forum findForumByAccessLevel(long accessLevel);

}
