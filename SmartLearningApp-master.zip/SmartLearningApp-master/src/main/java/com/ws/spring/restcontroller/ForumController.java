package com.ws.spring.restcontroller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ws.spring.dto.CollegeDto;
import com.ws.spring.model.College;
import com.ws.spring.model.Forum;
import com.ws.spring.service.ForumServiceImpl;

import io.swagger.annotations.Api;

@RestController
@RequestMapping("/Forum")
@Api(value = "Forum Management System", tags = "Operations pertaining to Forum in Forum Management System")
public class ForumController
{
	@Autowired
	ForumServiceImpl forumService;
	
	@PostMapping("/v1/createForum")
	ResponseEntity<String> createForum(@RequestBody Forum forum) {
		Forum forumCreated = forumService.createForum(forum);
		return ResponseEntity.created(URI.create("/forum/v1/queryForumById/" + forumCreated.getForumId())).body("");
	}


}
