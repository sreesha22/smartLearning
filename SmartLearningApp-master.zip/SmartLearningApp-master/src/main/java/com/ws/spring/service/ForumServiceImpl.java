package com.ws.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ws.spring.model.Forum;
import com.ws.spring.model.Group;
import com.ws.spring.repository.ForumRepository;

@Service
public class ForumServiceImpl 
{

	@Autowired
	ForumRepository forumRepository;
	
	public Forum createForum(Forum forum) {
		return forumRepository.save(forum);
	}
	public Forum queryForumByForumId(long forumId) {
		return forumRepository.findForumByForumId(forumId);
	}
	
	public Forum queryForumByForumName(long forumName) {
		return forumRepository.findForumByForumId(forumName);
	}
	
	public Forum queryForumByAccessLEvel(long accessLevel) {
		return forumRepository.findForumByAccessLevel(accessLevel);
	}
}
